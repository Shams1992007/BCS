from api.models import Question
from api.serializers import QuestionSerializer
import pandas as pd


def run():
    df = pd.read_csv('questiondata.csv', sep = ',')



    print(df.head())
    print()
    print(df.columns)

    # csv_file_column_names = ['subject', 'question', 'option 1', 'option 2', 'option 3', 'option 4', 'correct answer', 'bcs_year', 'banks', 'other_government','difficulty']

    #Must have fields = [questionText, option1, option2, option3, option4,correctAnswer,subject, difficulty, isBcs, bcsNumber, isBank, bankName, isGovt, govtName]

    questions = []

    for index, row in df.iterrows():
        questionText = row['question']
        option1 = row['option 1']
        option2 = row['option 2']
        option3 = row['option 3']
        option4 = row['option 4']

        correctAnswer = row['correct answer']

        if correctAnswer==option1:
            correctAnswerOption = 1
        elif correctAnswer==option2:
            correctAnswerOption = 2
        elif correctAnswer==option3:
            correctAnswerOption = 3
        elif correctAnswer == option4:
            correctAnswerOption = 4
        else:
            print("wrong correct answer data at index %d" % index)
            continue

        subject = row['subject']
        difficulty = row['difficulty']

        bcsNumber = row['bcs_year']
        bankName = row['banks']
        govtName = row['other_government']

        isBcs = True if ((len(bcsNumber) > 0) and (bcsNumber != '0')) else False
        isBank = True if ((len(bankName) > 0) and (bankName != '0')) else False
        isGovt = True if ((len(govtName) > 0) and (govtName!= '0')) else False




        questions.append(Question(questionText = questionText,
        option_1 = option1,
        option_2 = option2,
        option_3 = option3,
        option_4 = option4,
        correctAnswer = correctAnswer,
        correctAnswerOption= correctAnswerOption,
        subject = subject,
        difficulty = difficulty,
        bcsNumber = bcsNumber,
        bankName = bankName,
        govtName = govtName,
        isBcs = isBcs,
        isBank = isBank,
        isGovt = isGovt))

    print("question creation started")
    Question.objects.bulk_create(questions)

    print()
    print("Done creating questions")





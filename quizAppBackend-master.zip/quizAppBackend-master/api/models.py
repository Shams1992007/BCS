import datetime
import uuid
import os
from pathlib import Path
import random
import time


import pandas as pd

from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
from django.dispatch import Signal
from django.db.models import Q

processRoundSignal = Signal(providing_args=['id'])
createRoundQuestionsSignal = Signal(providing_args=['id'])
scheduleNotificationForRoundSignal = Signal(providing_args=['id'])



# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

class Profile(models.Model):
    # User's Personal info related fields
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=100, default="", unique = True)
    profile_picture = models.ImageField(null = True, blank = True, upload_to = 'images/profile/')

    # User's current status related
    level = models.IntegerField(default=0, blank=False)
    points = models.IntegerField(default=0, blank= False)
    total_points = models.BigIntegerField(default=0, blank= False) 

    # Tournament related fields
    spentPointsForCurrentTournament = models.BooleanField(default=False, blank=False)
    tournamentTally = models.IntegerField(default=4, blank=False)

    def __str__(self):
        return str(self.user)

    



class SubjectQuestionFileUpload(models.Model):
    data = models.FileField(null = True, blank = True, upload_to = 'data/questiondata/')

    def __str__(self):
        if self is not None:
            return str(self.data).split('/')[2]
        else:
            return 'Unknown File'

    def save(self, *args, **kwargs):
        super(SubjectQuestionFileUpload, self).save(*args, **kwargs)
        filename = self.data
        print(filename)
        

        # Do anything you'd like with the data in filename
        df = pd.read_csv(filename, sep = ',', encoding = 'UTF-8')

        print(df.head())
        print()
        print(df.columns)

        questions = []
        wrong_correct_answer_indexes = []

        for index, row in df.iterrows():
            questionText = row['Question']
            option1 = row['Option A']
            option2 = row['Option B']
            option3 = row['Option C']
            option4 = row['Option D']

            correctAnswer = row['Answer']

            if correctAnswer==option1:
                correctAnswerOption = 1
            elif correctAnswer==option2:
                correctAnswerOption = 2
            elif correctAnswer==option3:
                correctAnswerOption = 3
            elif correctAnswer == option4:
                correctAnswerOption = 4
            else:
                print("wrong correct answer data at index %d" % index)
                wrong_correct_answer_indexes.append(index + 2)
                continue
            
            #Get subject info
            subject = row['Subject']

            #Get BCS Info
            bcsNumber = row['bcs_year']
            isBcs = True if row['is_bcs']==1 else False


            #Get difficulty info
            difficulty = row['difficulty']

            #Get source file data
            fileid = self

            questions.append(Question(questionText = questionText,
            option_1 = option1,
            option_2 = option2,
            option_3 = option3,
            option_4 = option4,
            correctAnswer = correctAnswer,
            correctAnswerOption= correctAnswerOption,
            subject = subject,
            isBcs=isBcs,
            bcsNumber = bcsNumber,
            difficulty = difficulty,
            fileid = fileid
            ))

        print("wrong correct answer indexes")
        print(wrong_correct_answer_indexes)
        
        print("question creation started")
        Question.objects.bulk_create(questions)

        print()
        print("Done creating questions")


class Question(models.Model):
    '''
    Must have fields = [questionText, option1, option2, option3, option4,
    correctAnswer]
    '''
    questionText = models.CharField(max_length=512, blank= False)
    option_1 = models.CharField(max_length=128, blank= False)
    option_2 = models.CharField(max_length=128, blank= False)
    option_3 = models.CharField(max_length=128, blank= False)
    option_4 = models.CharField(max_length=128, blank= False)

    class CorrectAnswer(models.IntegerChoices):
        A = 1
        B = 2
        C = 3
        D = 4

    correctAnswerOption = models.IntegerField(choices= CorrectAnswer.choices, default= 1)
    correctAnswer = models.CharField(max_length=128, default="", blank= False)

    subject = models.CharField(max_length=128, blank= False, default="")
    difficulty = models.IntegerField(default=0)
    isBcs = models.BooleanField(default=False)
    bcsNumber = models.CharField(max_length=128, blank= True)
    isBank = models.BooleanField(default= False)
    bankName = models.CharField(max_length=128, blank = True)
    isGovt = models.BooleanField(default= False)
    govtName = models.CharField(max_length= 128, blank= True)

    #Optional field (file Id). Identify the file id this question comes from
    fileid = models.ForeignKey(SubjectQuestionFileUpload, default=None,blank=True,null=True, on_delete= models.CASCADE)

    recentlyInTournament = models.BooleanField(default=False)


    def __str__(self):
        return str(str(self.difficulty) + '_' + self.questionText)


class PracticeExamHistory(models.Model):
    user = models.ForeignKey(User, on_delete= models.CASCADE)
    exam_name = models.CharField(max_length=128, blank=False, default='')
    date_of_exam = models.DateTimeField(auto_now_add= True, blank= False)
    score = models.IntegerField(default=0, blank= False)

    def __str__(self):
        return str(self.exam_name)






class Tournament(models.Model):
    name = models.CharField(max_length=64, blank=False)

    startTime = models.DateTimeField(blank=False, unique= True, default=timezone.now)

    endTime = models.DateTimeField(default=timezone.now)
    
    tournamentType = models.CharField(max_length = 16, default='weekly', blank= False)
    weekNumber = models.IntegerField(default=1, blank=False)

    numberOfRounds = models.IntegerField(default=1, blank=False)

    tournamentWinners = models.ManyToManyField(User)

    TournamentFinished = models.BooleanField(default= False)
    

    def __str__(self):
        return str(self.name)



class Round(models.Model):
    KNOCKOUT = 'KN'
    REGULAR = 'RE'
    
    ROUND_TYPE_CHOICES = [(REGULAR, 'Regular'), (KNOCKOUT, 'Knockout')]

    id = models.AutoField(primary_key=True)
    tournament= models.ForeignKey(Tournament, on_delete= models.CASCADE)
    
    roundType= models.CharField(max_length=512, choices=ROUND_TYPE_CHOICES, default=REGULAR)

    startTime = models.DateTimeField(blank=False, unique=True)
    perQuestionTime = models.DurationField(default=30, blank= False)
    numberOfQuestions = models.IntegerField(default=20, blank=False)

    #Serial of round in it's parent tournament
    roundNumber = models.IntegerField(default=1, blank=False)

    processedStatus = models.BooleanField(default=False, blank= False)

    @property
    def name(self):
        return str(self.tournament.name)+' Round '+str(self.roundNumber)

    def __str__(self):
        return str(self.name)


    def randomQuestionSelection(self, allQuestions, noSelected):
        randomly_selected_questions = []
        number_of_available_questions = allQuestions.count()
        if number_of_available_questions>noSelected:
            random_indexes = random.sample(range(number_of_available_questions), noSelected)
            randomly_selected_questions = [allQuestions[i] for i in random_indexes]
        else:
            randomly_selected_questions = allQuestions
        return randomly_selected_questions


    def save(self, *args, **kwargs):
        roundSavingStart = time.time()
        if self.id is None:
            prevRounds = Round.objects.filter(tournament= self.tournament)
            # print(str(prevRounds))
            # print(len(prevRounds))
            # print()
            self.roundNumber= len(prevRounds)+1
            super(Round, self).save(*args, **kwargs)

            # minDifficulty = 0
            # maxDifficulty = 8

            # if(self.roundType == 'RE'):
            #     minDifficulty = 4
            #     maxDifficulty = 5
            # elif(self.roundType == 'KN'):
            #     minDifficulty = 6
            #     maxDifficulty = 7
            

            # numberOfMathQuestions = self.numberOfQuestions//2
            # numberOfBanglaQuestions = self.numberOfQuestions//4
            # numberOfEnglishQuestions = self.numberOfQuestions -(numberOfMathQuestions + numberOfBanglaQuestions)

            # allMathQuestions = Question.objects.filter(Q(subject='Math') & Q(difficulty__range= (minDifficulty,maxDifficulty)) & Q(recentlyInTournament = False))

            # allBanglaQuesions = Question.objects.filter(Q(subject='Bangla') & Q(difficulty__range= (minDifficulty,maxDifficulty)) & Q(recentlyInTournament = False))

            # allEnglishQuestions = Question.objects.filter(Q(subject='English') & Q(difficulty__range= (minDifficulty,maxDifficulty)) & Q(recentlyInTournament = False))

            # mathQuestions= self.randomQuestionSelection(allMathQuestions, numberOfMathQuestions)
            # banglaQuesions = self.randomQuestionSelection(allBanglaQuesions, numberOfBanglaQuestions)
            # englishQuestions = self.randomQuestionSelection(allEnglishQuestions, numberOfEnglishQuestions)


            # # Randomly select some questions for this round
            # # selectedQuestions = mathQuestions.union(banglaQuesions,englishQuestions)
            # selectedQuestions = mathQuestions + banglaQuesions + englishQuestions

            # updatedQuestions = []
            # newRoundQuestionMappings = []
            
            # # populate the RoundToQuestionMapping table with this questions
            # for i,q  in enumerate(selectedQuestions):
            #     #Update question used field
            #     q.recentlyInTournament = True
            #     updatedQuestions.append(q)
            #     # q.save()

            #     #create round question mappings
            #     questionEntry = RoundToQuestionMapping(round=self, question=q, questionSerialNumber = i+1)
            #     newRoundQuestionMappings.append(questionEntry)
            #     # questionEntry.save()

            # #Do database transactions in bulk
            # Question.objects.bulk_update(updatedQuestions, ['recentlyInTournament'])

            # RoundToQuestionMapping.objects.bulk_create(newRoundQuestionMappings)

            #call task to create questions for round
            # createRoundQuestionsSignal.send(sender = Round, id = self.id)

            #call task to process round
            processRoundSignal.send(sender= Round, id = self.id)
            scheduleNotificationForRoundSignal.send(sender = Round, id = self.id)

            
        else:
            super(Round, self).save(*args, **kwargs)

        roundSavingTime= time.time() - roundSavingStart
        print('time to create round ' + str(roundSavingTime))






class RoundToQuestionMapping(models.Model):
    round = models.ForeignKey(Round, on_delete= models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    questionSerialNumber = models.IntegerField(default=0)


class TournamentScores(models.Model):
    user = models.ForeignKey(User, on_delete= models.CASCADE)
    tournament = models.ForeignKey(Tournament, on_delete= models.CASCADE)
    round = models.ForeignKey(Round, on_delete=models.CASCADE)
    score = models.DecimalField(default=0, max_digits= 6, decimal_places=2)
    
    class Meta:
        unique_together = ('user', 'tournament', 'round')

class TournamentRanking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    ranking = models.IntegerField(default=None)
    playedRounds = models.IntegerField(default=None)
    totalScore = models.DecimalField(default=None, max_digits= 6, decimal_places=2)

    class Meta:
        unique_together = ('user', 'tournament')


    






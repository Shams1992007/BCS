from django.urls import path
from .views import UserRecordView, secret, QuestionViewSet, QuestionNestedView

from .questionviews import QuestionNestedViewFiltered

from .UserAndProfileViews import ShowUserData, CreateUserView, UpdateUserView, LoginView, ProfileView, PracticeExamHistoryView

from .TournamentViews import tournamentView, roundsInTournamentView, roundQuestionsView, spendPointsForTournament, createTournamentRoundScoreForUser, getTournamentRoundScoreForUser, TournamentRelatedInfoView

from .LeaderboardViews import LifeTimeRankView, TournamentRankView

from rest_framework.routers import DefaultRouter

from fcm_django.api.rest_framework import FCMDeviceAuthorizedViewSet



router = DefaultRouter()
# router.register('questions_all', QuestionViewSet, basename = 'questions')
router.register(r'devices', FCMDeviceAuthorizedViewSet)

app_name = 'api'
urlpatterns = [
    path('userrecords/', UserRecordView.as_view(), name='show all users'),
    path('register/', CreateUserView.as_view(), name= 'register'),
    path('updateuser/<int:pk>/', UpdateUserView.as_view(), name = 'update user data'),
    path('login/', LoginView.as_view(), name = 'login'),
    path('profile/', ProfileView.as_view(), name = 'profile'),
    # path('secret/', secret),
    # path('nestedquestions/', QuestionNestedView.as_view(), name = 'nested questions'),
    path('questions/', QuestionNestedViewFiltered.as_view(), name = 'nested questions filtered'),
    path('userdata/', ShowUserData.as_view(), name = 'user data for display'),
    path('practiceexamhistory/', PracticeExamHistoryView.as_view(), name = 'practice exam history create and see'),
    path('spendpointsfortournament/', spendPointsForTournament, name='Spend points for tournament'),
    path('tournaments/', tournamentView.as_view(), name = 'tournament details view'),
    path('roundsintournament/', roundsInTournamentView.as_view(), name = "Show the rounds in a tournament"),
    path('roundquestions/', roundQuestionsView.as_view(), name = "Show the questions in a round"),
    path('createtournamentscores/', createTournamentRoundScoreForUser.as_view(), name= "post scores for user in a round of a tournament" ),
    path('gettournamentscores/',getTournamentRoundScoreForUser.as_view(), name = "get scores for user in a round of a tournament"),
    path('lifetimerank/', LifeTimeRankView.as_view(), name = "lifetime rank"),
    path('tournamentrank/', TournamentRankView.as_view(), name = "tournament rank"),
    path('tournamentrelatedinfo/', TournamentRelatedInfoView.as_view(), name= "tournament related info"),
]

urlpatterns += router.urls
# urlpatterns = patterns('',
#         # URLs will show up at <api_root>/devices
#         # DRF browsable API which lists all available endpoints
#         url(r'^', include(router.urls)),
#         # ...
# )
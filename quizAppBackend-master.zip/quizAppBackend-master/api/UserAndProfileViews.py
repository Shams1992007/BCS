from django.contrib.auth.models import User
from django.contrib.auth import authenticate

from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.generics import CreateAPIView, UpdateAPIView
from rest_framework.parsers import JSONParser, MultiPartParser
from rest_framework.decorators import api_view

from .serializers import UserSerializer, ProfileSerializer, UpdateUserSerializer, PracticeExamHistorySerializer
from .models import Profile, PracticeExamHistory


class ShowUserData(APIView):
    model = User
    permission_classes = [IsAuthenticated]
    serializer_class = UserSerializer

    def get(self, request, format = None):
        try:
            currentUser = request.user
            currentSerializedUser = UserSerializer(currentUser)
            return Response(data= currentSerializedUser.data, status=status.HTTP_200_OK)
        except:
            return Response(data=None, status=status.HTTP_404_NOT_FOUND)


class CreateUserView(CreateAPIView):
    parser_classes = [JSONParser, MultiPartParser]
    model = User
    permission_classes = [
        AllowAny # Or anon users can't register
    ]
    serializer_class = UserSerializer

    def get(self, format = None):
        return Response(data = None, status=status.HTTP_200_OK)


class UpdateUserView(UpdateAPIView):
    queryset = User.objects.all()
    permission_classes = (IsAuthenticated,)
    serializer_class = UpdateUserSerializer




class LoginView(APIView):
    permission_classes = ()

    def post(self, request,):
        username = request.data.get("username")
        password = request.data.get("password")
        user = authenticate(username=username, password=password)
        if user:
            return Response({"token": user.auth_token.key})
        else:
            return Response({"error": "Wrong Credentials"}, status=status.HTTP_400_BAD_REQUEST)


class ProfileView(APIView):
    parser_classes = [JSONParser, MultiPartParser]
    model = Profile
    permission_classes= [ IsAuthenticated ]
    serializer_class = ProfileSerializer

    def get(self, request, format = None):
        try:
            profile = request.user.profile
            serializer = ProfileSerializer(profile)
            return Response(data = serializer.data, status= status.HTTP_200_OK)
        except:
            return Response(data=None, status=status.HTTP_404_NOT_FOUND)

    def post(self, request, format = None):
        serializer = ProfileSerializer(data=request.data)
        user = request.user
        if serializer.is_valid(raise_exception=ValueError):
            serializer.create(user=user, validated_data = serializer.validated_data)
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED
            )
        return Response(
            {
                "error": True,
                "error_msg": serializer.error_messages,
            },
            status=status.HTTP_400_BAD_REQUEST
        )

    def put(self, request, format = None):
        previous_profile = request.user.profile
        serializer = ProfileSerializer(previous_profile, data = request.data)
        if serializer.is_valid(raise_exception=ValueError):
            serializer.save()
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED
            )
        return Response(
            {
                "error": True,
                "error_msg": serializer.error_messages,
            },
            status=status.HTTP_400_BAD_REQUEST
        ) 



class PracticeExamHistoryView(APIView):
    parser_classes = [JSONParser, MultiPartParser]
    model = PracticeExamHistory
    permission_classes= [ IsAuthenticated ]
    serializer_class = PracticeExamHistorySerializer

    def get(self, request, format = None):
        try:
            examHistory = PracticeExamHistory.objects.filter(user=request.user).order_by('-date_of_exam')[:5]
            serializer = PracticeExamHistorySerializer(examHistory, many= True)
            return Response(data = serializer.data, status= status.HTTP_200_OK)
        except:
            return Response(data=None, status=status.HTTP_404_NOT_FOUND)

    def post(self, request):
        serializer = PracticeExamHistorySerializer(data=request.data)
        # user = request.user
        if serializer.is_valid(raise_exception=ValueError):
            serializer.create( validated_data = serializer.validated_data)
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED
            )
        return Response(
            {
                "error": True,
                "error_msg": serializer.error_messages,
            },
            status=status.HTTP_400_BAD_REQUEST
        )




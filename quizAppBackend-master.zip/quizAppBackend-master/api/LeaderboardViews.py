from django.core.paginator import Paginator
from django.utils import timezone
from django.db.models import Sum
from django.contrib.auth.models import User

from django.db.models import F
from django.db.models.expressions import Window
from django.db.models.functions import Rank, DenseRank, RowNumber

from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from rest_framework.views import APIView


from .models import Profile, TournamentScores, Tournament, TournamentRanking
from .serializers import ProfileSerializer, RankingPageSerializer, LifetimeRankingPageSerializer

class RankingPage():
    def __init__(self, ranking_list=None, username_list=None,points_list=None,previous_page=None, next_page=None, current_page=None,last_page = None, ranking = None, topThreeUsernames=None, topThreeProfilePictures = None):
        self.ranking_list = ranking_list
        self.username_list = username_list
        self.points_list = points_list
        self.previous_page = previous_page
        self.next_page = next_page
        self.current_page = current_page
        self.last_page = last_page
        self.ranking = ranking
        self.topThreeUsernames = topThreeUsernames
        self.topThreeProfilePictures = topThreeProfilePictures





class LifeTimeRankView(APIView):

    def get_profile_page_ranking_data(self, pageNumber, user, rank = None):
        allProfiles = Profile.objects.all().order_by('-total_points').annotate(
            rank=Window(
                expression=Rank(),
                order_by=F('total_points').desc()
            ),
        )

        if rank is None:
            for profile in allProfiles:
                if profile.user == user:
                    rank = profile.rank
                    break
                else:
                    continue

        #Get the number of items in each page
        numberOfItems = 10
        profilePaginator = Paginator(allProfiles, numberOfItems)

        # Get the page number
        page_number = pageNumber

        # Get the required page based on page number
        page_obj = profilePaginator.get_page(page_number)

        #Save the total_points of these page to the result serializer
        total_points_list = []

        for obj in page_obj:
            total_points_list.append(obj.total_points)

        # Save the username of this page to the result serializer
        username_list = []

        for obj in page_obj:
            username_list.append(obj.user.username)

        # Calculate the rankings
        start_rank = (page_number-1)*numberOfItems + 1
        end_rank = min(start_rank + numberOfItems, start_rank + len(page_obj))
        ranking_list = [i for i in range( start_rank, end_rank)]

        #Get the next and previous pages
        next_page = None
        previous_page = None
        last_page = profilePaginator.num_pages

        #Get ranking
        ranking = rank

        if page_obj.has_next():
            next_page = page_obj.next_page_number()

        if page_obj.has_previous():
            previous_page =page_obj.previous_page_number()

        # print(ranking_list)
        # print(total_points_list)
        # print(username_list)

        # serializer = ProfileSerializer(page_obj, many = True)

        # Get top tournament names and profile pictures
        if len(allProfiles)>= 3:
            topThreeUsers = allProfiles[:3]
        else:
            topThreeUsers = allProfiles
        
        topThreeUsernames = []
        topThreeProfilePictures = []
        for topProfile in topThreeUsers:
            topuser = topProfile.user
            topThreeUsernames.append(topuser.username)
            topThreeProfilePictures.append(topuser.profile.profile_picture)

        currentPage = RankingPage(ranking_list = ranking_list, username_list= username_list, points_list = total_points_list, current_page = page_number, next_page= next_page, previous_page= previous_page,last_page=last_page, ranking= ranking, topThreeUsernames=topThreeUsernames, topThreeProfilePictures= topThreeProfilePictures)

        serializer = LifetimeRankingPageSerializer(currentPage)
        return serializer.data

    def get(self, request):
        user = request.user
        # Get the page number
        profile_set = Profile.objects.all().annotate(
            row=Window(
                expression=RowNumber(),
                order_by=F('total_points').desc()
            ),
            rank=Window(
                expression=Rank(),
                order_by=F('total_points').desc()
            ),
        )

        for profile in profile_set:
            if profile.user == user:
                rank = profile.rank
                row = profile.row
                page_number = ((row-1)//10)+1
                break
            else:
                continue

        print("queryset length " + str(len(profile_set)))
        print("rank is " + str(rank))
        print("row number is " + str(row))
        print("page number this rank resides in " + str(page_number))
        

        pageData = self.get_profile_page_ranking_data(page_number, user, rank = rank)
        return Response(data= pageData, status= status.HTTP_200_OK) 


    def post(self, request):
        page_number = request.data.get('page_number')

        try:
            pageData = self.get_profile_page_ranking_data(page_number, request.user)
            return Response(data= pageData, status= status.HTTP_200_OK)
        except:
            return Response({"error": "Page does not exist"}, status = status.HTTP_400_BAD_REQUEST)





class TournamentRankView(APIView):

    def get_tournament_ranking_data(self, pageNumber, user, ranking = None):
        
        tournaments = Tournament.objects.order_by('-startTime')

        lastTournamentId = 0
        if tournaments is None:
            pass
        else:
            tournament = tournaments[0]
            lastTournamentId = tournament.id

        # allTournamentScores = TournamentScores.objects.filter(tournament=lastTournamentId).values('tournament','user').annotate(totalscore = sum('score')).order_by('-totalscore')
        # allTournamentScores = TournamentScores.objects.filter(tournament=lastTournamentId).values('tournament','user').annotate(totalscore=Sum('score')).order_by('-totalscore').annotate(
        #     rank=Window(
        #         expression=Rank(),
        #         order_by=F('totalscore').desc()
        #     ),
        # )

        allTournamentScores = TournamentRanking.objects.filter(tournament=lastTournamentId).order_by('ranking', '-totalScore')

        # print(allTournamentScores)

        if ranking is None:
            for tournamentScore in allTournamentScores:
                if tournamentScore.user == user.id:
                    ranking = tournamentScore.ranking
                    break
                else:
                    continue


        #Get the number of items in each page
        numberOfItems = 10
        scorePaginator = Paginator(allTournamentScores, numberOfItems)

        page_number = pageNumber

        # Get the required page based on page number
        page_obj = scorePaginator.get_page(page_number)

        #Save the total_points of these page to the result serializer
        total_points_list = []

        for obj in page_obj:
            total_points_list.append(obj.totalScore)

        # Save the username of this page to the result serializer
        username_list = []

        for obj in page_obj:
            userid = obj.user.pk
            userQuery = User.objects.filter(id = userid)
            user = userQuery[0]
            username_list.append(user.username)

        # Calculate the rankings
        start_rank = (page_number-1)*numberOfItems + 1
        end_rank = min(start_rank + numberOfItems, start_rank + len(page_obj))
        ranking_list = [i for i in range( start_rank, end_rank)]

        #Get the next and previous pages
        next_page = None
        previous_page = None
        last_page = scorePaginator.num_pages

        if page_obj.has_next():
            next_page = page_obj.next_page_number()

        if page_obj.has_previous():
            previous_page =page_obj.previous_page_number()

        # print(ranking_list)
        # print(total_points_list)
        # print(username_list)

        # serializer = ProfileSerializer(page_obj, many = True)

        # Get top tournament names and profile pictures
        if len(allTournamentScores)>= 3:
            topThreeUsers = allTournamentScores[:3]
        else:
            topThreeUsers = allTournamentScores
        
        topThreeUsernames = []
        topThreeProfilePictures = []
        for tournamentScore in topThreeUsers:
            userid = tournamentScore.user.pk
            topuser = User.objects.get(id = userid)
            topThreeUsernames.append(topuser.username)
            topThreeProfilePictures.append(topuser.profile.profile_picture)


        currentPage = RankingPage(ranking_list = ranking_list, username_list= username_list, points_list = total_points_list, current_page = page_number, next_page= next_page, previous_page= previous_page, last_page= last_page, ranking= ranking, topThreeUsernames=topThreeUsernames, topThreeProfilePictures= topThreeProfilePictures)

        serializer = RankingPageSerializer(currentPage)
        return serializer.data



    def get(self, request):
        user = request.user
        rank = None
        row = None
        page_number = 1


        tournaments = Tournament.objects.order_by('-startTime')

        lastTournamentId = 0
        if tournaments is None:
            pass
        else:
            tournament = tournaments[0]
            lastTournamentId = tournament.id

        
        # allTournamentScores = TournamentScores.objects.filter(tournament=lastTournamentId).values('tournament','user').annotate(totalscore=Sum('score')).order_by('-totalscore').annotate(
        #     row=Window(
        #         expression=RowNumber(),
        #         order_by=F('totalscore').desc()
        #     ),
        #     rank=Window(
        #         expression=Rank(),
        #         order_by=F('totalscore').desc()
        #     ),
        # )

        allTournamentScores = TournamentRanking.objects.filter(tournament=lastTournamentId).order_by('ranking', '-totalScore').annotate(row= Window(
            expression=RowNumber(),
            order_by=F('totalScore').desc(),
            partition_by=[F('ranking')],
            )
            )

        # print(allTournamentScores)

        for tournamentScore in allTournamentScores:
            if tournamentScore.user == user.id:
                rank = tournamentScore.ranking
                row = tournamentScore.row
                page_number = ((row-1)//10)+1
                break
            else:
                continue

        # Get the page number
        page_number = page_number

        pageData = self.get_tournament_ranking_data(page_number, user, rank)
        return Response(data= pageData, status= status.HTTP_200_OK) 


    def post(self, request):
        page_number = request.data.get('page_number')

        try:
            pageData = self.get_tournament_ranking_data(page_number, request.user)
            return Response(data= pageData, status= status.HTTP_200_OK)
        except:
            return Response({"error": "Page does not exist"}, status = status.HTTP_400_BAD_REQUEST)
    
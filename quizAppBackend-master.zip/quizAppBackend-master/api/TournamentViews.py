from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.utils import timezone
from django.db.models import Q

from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.generics import CreateAPIView, UpdateAPIView
from rest_framework.parsers import JSONParser, MultiPartParser, FormParser
from rest_framework.decorators import api_view

from .serializers import UserSerializer, ProfileSerializer, UpdateUserSerializer, PracticeExamHistorySerializer, TournamentSerializer, RoundSerializer, QuestionSerializer, TournamentScoresSerializer, UsernameListSerializer, TournamentRelatedInfoSerializer


from .models import Profile, PracticeExamHistory, Tournament, Round, RoundToQuestionMapping, TournamentScores, TournamentRanking

from .tasks import processRound

class tournamentView(APIView):
    
    def get(self, request):
        tournaments = Tournament.objects.filter(endTime__gte = timezone.now()).order_by('startTime')

        if len(tournaments)>0:
            try:
                serializer = TournamentSerializer(tournaments, many = True)
                return Response(data= serializer.data, status= status.HTTP_200_OK)
            except:
                return Response({'error':'Error processing tournament data'}, status=status.HTTP_404_NOT_FOUND)
        else:
            return Response({'error':'No upcoming or running tournament'}, status=status.HTTP_404_NOT_FOUND)



class roundsInTournamentView(APIView):
    
    def post(self,request):
        tournamentId = request.data.get('tournamentId')
        rounds = Round.objects.filter(tournament= tournamentId).order_by('startTime')
        if len(rounds)>0:
            serializer = RoundSerializer(rounds, many = True)
            return Response(data = serializer.data , status=status.HTTP_200_OK)
        else:
            return Response({"error": "No rounds in this tournament"}, status=status.HTTP_404_NOT_FOUND)



class roundQuestionsView(APIView):
    
    def post(self,request):
        roundId = request.data.get('roundId')
        # result = processRound.delay(roundId)
        # print(result)
        questionEntries = RoundToQuestionMapping.objects.filter(round=roundId)
        questions = [questionEntry.question for questionEntry in questionEntries]
        if (len(questions)>0):
            serializer = QuestionSerializer(questions, many = True)
            return Response(data = serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({"error":"No questions in round"}, status= status.HTTP_404_NOT_FOUND)



@api_view(['GET'])
def spendPointsForTournament(request):
    profile = request.user.profile
    if (profile.points >= 10000):
        profile.points -= 10000
        profile.spentPointsForCurrentTournament = True
        profile.save()
        serializer = ProfileSerializer(request.user.profile)
        return Response(serializer.data, status= status.HTTP_202_ACCEPTED)
    else:
        return Response({"error": "Insufficient points"}, status = status.HTTP_400_BAD_REQUEST)



class createTournamentRoundScoreForUser(APIView):

    def post(self, request):
        serializer = TournamentScoresSerializer(data=request.data)
        if serializer.is_valid(raise_exception=ValueError):
            serializer.create( validated_data = serializer.validated_data)
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED
            )
        return Response(
            {
                "error": True,
                "error_msg": serializer.error_messages,
            },
            status=status.HTTP_400_BAD_REQUEST
        )



class getTournamentRoundScoreForUser(APIView):

    def post(self, request):
        try:
            tournamentId = request.data.get('tournament')
            
            roundId = request.data.get('round')
            
            userId = request.data.get('user')
            
            score = TournamentScores.objects.filter(Q(tournament = tournamentId) & Q(round = roundId) & Q(user = userId))
            
            if score:
                serializer = TournamentScoresSerializer(score, many = True)
                print(serializer.data)
                return Response(serializer.data , status=status.HTTP_200_OK)
            else:
                return Response({"error":"Score does not exist"}, status=status.HTTP_404_NOT_FOUND)
        except:
            return Response({"error":"Corrupted request"}, status=status.HTTP_400_BAD_REQUEST)


class UserNameList():
    def __init__(self, username_list = None):
        self.username_list = username_list

class getTournamentWinnersView(APIView):
    def post(self, request):
        try:
            tournamentId = request.data.get('tournament')
            currentTournament = Tournament.objects.filter(id = tournamentId)
            winners = currentTournament.tournamentWinners.all()
            winnerUsernameList = []
            for winner in winners:
                winnerUsernameList.append(winner.username)

            currentUserNameList = UserNameList(username_list= winnerUsernameList)
            UserNameSerializer = UsernameListSerializer(currentUserNameList)

            return Response(data= UserNameSerializer.data, status= status.HTTP_200_OK) 
        except:
            return Response({"error":"Corrupted request"}, status=status.HTTP_400_BAD_REQUEST)

class TournamentRelatedInfo():
    def __init__(self, tournamentName = None, completionStatus = None, participationStatus = None, winnerStatus = None, winners_username_list = None, nextRoundNumber = None, nextRoundEligibilityStatus = None, nextRoundStartTime = None):
        self.tournamentName = tournamentName
        self.completionStatus = completionStatus
        self.participationStatus = participationStatus
        self.winnerStatus = winnerStatus
        self.winners_username_list = winners_username_list
        self.nextRoundNumber = nextRoundNumber
        self.nextRoundEligibilityStatus = nextRoundEligibilityStatus
        self.nextRoundStartTime = nextRoundStartTime

class TournamentRelatedInfoView(APIView):

    def generateTournamentInfo(self, runningTournament,user, currentTime, completionStatus):
        ranking = TournamentRanking.objects.filter(tournament=runningTournament, user = user)

        if (user.profile.spentPointsForCurrentTournament) or (len(ranking)>0):
            participationStatus = True
        else:
            participationStatus = False

        winners = runningTournament.tournamentWinners.all()
        if user in winners:
            winnerStatus = True
        else: 
            winnerStatus = False

        winners_list = []
        for winner in winners:
            winners_list.append(winner.username)

        currentRoundQuery = Round.objects.filter(tournament=runningTournament,startTime__lt=currentTime, processedStatus = False)

        currentRound = None
        if len(currentRoundQuery) > 0:
            currentRound = currentRoundQuery[0]

        nextRounds = Round.objects.filter(tournament=runningTournament, startTime__gt = currentTime).order_by('startTime')

        nextRound = None
        nextRoundNumber = None
        nextRoundEligibilityStatus = None
        nextRoundStartTime = None
        if len(nextRounds)>0:
            nextRound = nextRounds[0]
            nextRoundNumber = nextRound.roundNumber
            nextRoundStartTime = nextRound.startTime
            
        if currentRound is not None:
            nextRoundEligibilityStatus = 'Pending'
        else:
            if user.profile.spentPointsForCurrentTournament:
                nextRoundEligibilityStatus = 'Eligible'
            else:
                nextRoundEligibilityStatus = 'Not Eligible'
                



        tournamentRelatedInfo = TournamentRelatedInfo(tournamentName=runningTournament.name, completionStatus=completionStatus, participationStatus= participationStatus, winnerStatus=winnerStatus, winners_username_list=winners_list, nextRoundNumber= nextRoundNumber, nextRoundEligibilityStatus=nextRoundEligibilityStatus, nextRoundStartTime=nextRoundStartTime)

        return tournamentRelatedInfo

    def get(self, request):
        
        user = request.user
        
        #Find the most relevant tournment
        currentTime = timezone.now()
        
        runningTournaments = Tournament.objects.filter(startTime__lte = currentTime, endTime__gte = currentTime).order_by('-startTime')

        runningTournament = None
        if len(runningTournaments) > 0:
            runningTournament = runningTournaments[0]

        upcomingTournaments = Tournament.objects.filter(startTime__gte = currentTime).order_by('startTime')

        upcomingTournament = None
        if len(upcomingTournaments)> 0:
            upcomingTournament = upcomingTournaments[0]

        previousTournaments = Tournament.objects.filter(endTime__lte = currentTime).order_by('-endTime')

        previousTournament = None
        if len(previousTournaments)> 0:
            previousTournament = previousTournaments[0]

        if runningTournament is not None:
            serializableTournamentInfo = self.generateTournamentInfo( runningTournament,user, currentTime, 'running')
        elif upcomingTournament is not None:
            serializableTournamentInfo = self.generateTournamentInfo( upcomingTournament,user, currentTime,  'upcoming')
        elif previousTournament is not None:
            serializableTournamentInfo = self.generateTournamentInfo( previousTournament,user, currentTime,  'previous')

        try:
            serializer = TournamentRelatedInfoSerializer(serializableTournamentInfo)
            return Response(data= serializer.data, status= status.HTTP_200_OK)
        except:
            return Response({'error':'Error processing tournament data'}, status=status.HTTP_404_NOT_FOUND)
        

        
        

            


            













from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token

from rest_framework import serializers
from rest_framework.validators import UniqueTogetherValidator
from .models import Profile, Question, PracticeExamHistory, Tournament, Round, TournamentScores



class ProfileSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Profile
        fields = (
            'phone_number',
            'profile_picture',
            'level',
            'points',
            'total_points',
            'tournamentTally',
            'spentPointsForCurrentTournament',
        )
        
    # def create(self, validated_data):
    #     profile = Profile.objects.create( **validated_data)
    #     return profile
    def create(self, validated_data, user):
        profile = Profile.objects.create(user = user, **validated_data)
        return profile


    def update(self, instance , validated_data):

        instance.phone_number = validated_data.get('phone_number', instance.phone_number)

        instance.profile_picture = validated_data.get('profile_picture', instance.profile_picture)

        instance.points = validated_data.get('points', instance.points)

        instance.level = validated_data.get('level', instance.level)

        instance.total_points = validated_data.get('total_points', instance.total_points)

        instance.save()
        return instance

class UserSerializer(serializers.ModelSerializer):
    # profile = ProfileSerializer()

    def create(self, validated_data):
        # profile_data = validated_data.pop('profile')
        # user = User.objects.create_user(**validated_data)
        # Profile.objects.create(user=user, **profile_data)
        user = User(
            email=validated_data['email'],
            username=validated_data['username'],
            first_name = validated_data['first_name'],
            last_name = validated_data['last_name'],
        )
        user.set_password(validated_data['password'])
        user.save()
        Token.objects.create(user=user)
        return user

    class Meta:
        model = User
        fields = (
            'id',
            'username',
            'email',
            'first_name',
            'last_name',
            'password',
        )
        extra_kwargs = {"password": {"write_only": True}}


class UpdateUserSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email')

    def validate_email(self, value):
        user = self.context['request'].user
        if User.objects.exclude(pk=user.pk).filter(email=value).exists():
            raise serializers.ValidationError({"email": "This email is already in use."})
        return value

    def validate_username(self, value):
        user = self.context['request'].user
        if User.objects.exclude(pk=user.pk).filter(username=value).exists():
            raise serializers.ValidationError({"username": "This username is already in use."})
        return value

    def update(self, instance, validated_data):
        instance.first_name = validated_data.get('first_name', instance.first_name)
        instance.last_name = validated_data.get('last_name', instance.last_name)
        instance.email = validated_data.get('email', instance.email)
        instance.username = validated_data.get('username', instance.username)

        instance.save()

        return instance



class QuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = ['id', 'questionText', 'option_1', 'option_2', 'option_3',
        'option_4', 'correctAnswerOption', 'correctAnswer' ]


# {
#   "string": "question",
#   "Answer1": {
#     "string": "ans",
#     "status": "incorrect"
#   },
#     "Answer2": {
#     "string": "ans",
#     "status": "incorrect"
#   },
#     "Answer3": {
#     "string": "ans",
#     "status": "correct"
#   },
#     "Answer4": {
#     "string": "ans",
#     "status": "incorrect"
#   }
#  }

class NestedAnswerSerializer(serializers.Serializer):
    
    string = serializers.CharField(max_length= 128)
    status = serializers.CharField(max_length = 20)

class QuestionWithNestedAnswersSerializer(serializers.Serializer):
    string = serializers.CharField(max_length = 512)
    Answer1 = NestedAnswerSerializer()
    Answer2 = NestedAnswerSerializer()
    Answer3 = NestedAnswerSerializer()
    Answer4 = NestedAnswerSerializer()

class PracticeExamHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = PracticeExamHistory
        fields = '__all__'


class TournamentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tournament
        fields = '__all__'

class RoundSerializer(serializers.ModelSerializer):
    class Meta:
        model = Round
        fields = '__all__'

class TournamentScoresSerializer(serializers.ModelSerializer):
    class Meta:
        model = TournamentScores
        fields = '__all__'



class RankingPageSerializer(serializers.Serializer):
    ranking_list = serializers.ListField(child= serializers.IntegerField(default=0)) 

    username_list = serializers.ListField(child = serializers.CharField(default='', max_length = 512))

    points_list = serializers.ListField(child= serializers.DecimalField(default=0, max_digits= 6, decimal_places=2)) 

    previous_page = serializers.IntegerField(default= None)
    next_page = serializers.IntegerField(default=None)
    current_page = serializers.IntegerField(default=None)
    last_page = serializers.IntegerField(default=None)
    ranking = serializers.IntegerField(default=None)

    topThreeUsernames = serializers.ListField(child = serializers.CharField(default='', max_length = 512))
    topThreeProfilePictures = serializers.ListField(child = serializers.CharField(default='', max_length = 512))
    
class LifetimeRankingPageSerializer(serializers.Serializer):
    ranking_list = serializers.ListField(child= serializers.IntegerField(default=0)) 

    username_list = serializers.ListField(child = serializers.CharField(default='', max_length = 512))

    points_list = serializers.ListField(child= serializers.IntegerField(default=0)) 

    previous_page = serializers.IntegerField(default= None)
    next_page = serializers.IntegerField(default=None)
    current_page = serializers.IntegerField(default=None)
    last_page = serializers.IntegerField(default=None)
    ranking = serializers.IntegerField(default=None)

    topThreeUsernames = serializers.ListField(child = serializers.CharField(default='', max_length = 512))
    topThreeProfilePictures = serializers.ListField(child = serializers.CharField(default='', max_length = 512))

class UsernameListSerializer(serializers.Serializer):
    username_list = serializers.ListField(child = serializers.CharField(default='', max_length = 512))

class TournamentRelatedInfoSerializer(serializers.Serializer):
    tournamentName = serializers.CharField(default=None, max_length = 512)
    completionStatus = serializers.CharField(default=None, max_length = 512)

    participationStatus = serializers.BooleanField(default=None)
    winnerStatus = serializers.BooleanField(default=None)

    winners_username_list =serializers.ListField(child = serializers.CharField(default='', max_length = 512))

    nextRoundNumber = serializers.IntegerField(default=None)
    nextRoundEligibilityStatus = serializers.CharField(default=None, max_length = 512)
    nextRoundStartTime = serializers.DateTimeField(default=None)
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User

from api.models import Profile, Question, SubjectQuestionFileUpload, PracticeExamHistory, Tournament, Round, RoundToQuestionMapping, TournamentScores, TournamentRanking

admin.site.register(Profile)

# Define an inline admin descriptor for Profile model
# which acts a bit like a singleton
class ProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False
    verbose_name_plural = 'profile'

# Define a new User admin
class UserAdmin(BaseUserAdmin):
    inlines = (ProfileInline,)

# Re-register UserAdmin
admin.site.unregister(User)
admin.site.register(User, UserAdmin)
admin.site.register(Question)
admin.site.register(SubjectQuestionFileUpload)
admin.site.register(PracticeExamHistory)
admin.site.register(TournamentScores)
admin.site.register(TournamentRanking)

class RoundToQuestionMappingInline(admin.StackedInline):
    model = RoundToQuestionMapping
    extra = 0
    readonly_fields = ['question','questionSerialNumber','round']
    
    def get_max_num(self, request, obj = None, **kwargs):
        max_num = 5
        if obj:
            max_num = obj.numberOfQuestions
        return max_num


class RoundAdmin(admin.ModelAdmin):
    inlines = [RoundToQuestionMappingInline, ]

admin.site.register(Round, RoundAdmin)



class RoundInline(admin.StackedInline):
    model = Round
    show_change_link = True
    extra = 0
    readonly_fields = ['roundNumber',]

    def get_max_num(self, request, obj = None, **kwargs):
        max_num = 5
        if obj:
            max_num = obj.numberOfRounds
        return max_num



class TournamentAdmin(admin.ModelAdmin):
    inlines = [RoundInline, ]
    readonly_fields = ['tournamentWinners',]

admin.site.register(Tournament, TournamentAdmin)






#########-------------------------------###################
# Nested Answer Question code start #
import random
from .serializers import QuestionWithNestedAnswersSerializer, NestedAnswerSerializer
from .models import Question

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from django.db.models import Q

class NestedAnswer():
    def __init__(self, answerText=None, statusText=None):
        self.string = answerText
        self.status = statusText

class QuestionNestedViewFiltered(APIView):

    def post(self, request):
        # get questions based on request body

        # questions = Question.objects.all()
        # # print(request.body)
        # print(request.data)
        # print(request.data['subject_name'])
        # print(request.data['exam_name'])
        # print(request.data['exam_type'])
        questions = Question.objects.none()
        filter_data = request.data

        if (filter_data['subject_name']):
            sub = filter_data['subject_name']
            questions = Question.objects.filter(subject=sub)
            # print("Number of objects returned %d" % questions.count())
            # print(questions[0])
        elif (filter_data['exam_name']):
            exam_name = filter_data['exam_name']
            questions = Question.objects.filter( Q(bcsNumber__icontains=exam_name )| Q(bankName__icontains = exam_name )| Q(govtName__icontains = exam_name))
            # print("Number of objects returned %d" % questions.count())
            # print(questions[0])

        randomly_selected_questions = []
        if filter_data['exam_type'] == 'quick': 
            number_of_available_questions = questions.count()
            if number_of_available_questions>20:
                random_20_indexes = random.sample(range(number_of_available_questions), 20)
                randomly_selected_questions = [questions[i] for i in random_20_indexes]
            else:
                randomly_selected_questions = [q for q in questions]
        elif filter_data['exam_type'] == 'full':
            number_of_available_questions = questions.count()
            if number_of_available_questions>200:
                random_200_indexes = random.sample(range(number_of_available_questions), 200)
                randomly_selected_questions = [questions[i] for i in random_200_indexes]
            else:
                randomly_selected_questions = [q for q in questions]
            
        print("number of selected questions %d" % len(randomly_selected_questions))

        serialized_questions = []
        for q in randomly_selected_questions:
            question_string = q.questionText
            answer1_string= q.option_1
            answer2_string = q.option_2
            answer3_string = q.option_3
            answer4_string = q.option_4

            answer1_status = 'incorrect'
            answer2_status = 'incorrect'
            answer3_status = 'incorrect'
            answer4_status = 'incorrect'

            if (q.correctAnswerOption==1):
                answer1_status = 'correct'
            elif (q.correctAnswerOption==2):
                answer2_status = 'correct'
            elif (q.correctAnswerOption == 3):
                answer3_status = 'correct'
            elif(q.correctAnswerOption == 4):
                answer4_status = 'correct'
            
            Answer1 = NestedAnswer(answer1_string, answer1_status)
            Answer2 = NestedAnswer(answer2_string, answer2_status)
            Answer3 = NestedAnswer(answer3_string, answer3_status)
            Answer4 = NestedAnswer(answer4_string, answer4_status)

            ans1_ser = NestedAnswerSerializer(Answer1)
            ans2_ser = NestedAnswerSerializer(Answer2)
            ans3_ser = NestedAnswerSerializer(Answer3)
            ans4_ser = NestedAnswerSerializer(Answer4)

            q_serialized = QuestionWithNestedAnswersSerializer(data = {
                'string':question_string,
                'Answer1':ans1_ser.data,
                'Answer2':ans2_ser.data,
                'Answer3':ans3_ser.data,
                'Answer4':ans4_ser.data
            })
            serialized_questions.append(q_serialized.initial_data)

        return Response(serialized_questions, status=status.HTTP_200_OK)

        
#########-------------------------------###################
# Nested Answer Question code end #
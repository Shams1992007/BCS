from .serializers import UserSerializer, ProfileSerializer, QuestionSerializer
from .models import Profile, Question

from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.permissions import AllowAny
from rest_framework.generics import CreateAPIView
from rest_framework.parsers import JSONParser, MultiPartParser
from rest_framework import viewsets
from django.contrib.auth.models import User


# create and show users
class UserRecordView(APIView):
    """
    API View to create or get a list of all the registered
    users. GET request returns the registered users whereas
    a POST request allows to create a new user.
    """
    permission_classes = [IsAdminUser]

    def get(self, format=None):
        users = User.objects.all()
        serializer = UserSerializer(users, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid(raise_exception=ValueError):
            serializer.create(validated_data=request.data)
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED
            )
        return Response(
            {
                "error": True,
                "error_msg": serializer.error_messages,
            },
            status=status.HTTP_400_BAD_REQUEST
        )

# @api_view(['POST'])
# def register(request):
#     permission_classes = [ AllowAny ]
#     serializer = UserSerializer(data=request.data)
#     if serializer.is_valid(raise_exception=ValueError):
#         serializer.create(validated_data=request.data)
#         return Response(
#             serializer.data,
#             status=status.HTTP_201_CREATED
#         )
#     return Response(
#         {
#             "error": True,
#             "error_msg": serializer.error_messages,
#         },
#         status=status.HTTP_400_BAD_REQUEST
#     )





@api_view(['GET'])
def secret(request):
    currentUser = request.user
    serializer = UserSerializer(currentUser)
    user_name = serializer.data['username']
    return Response(
        {
            "msg": "You have successfully logged IN!",
            "user": user_name,
        },
        status = status.HTTP_200_OK
    )
    
class QuestionViewSet(viewsets.ModelViewSet):
    queryset = Question.objects.all()
    serializer_class = QuestionSerializer

#########-------------------------------###################
# Nested Answer Question code start #
from .serializers import QuestionWithNestedAnswersSerializer, NestedAnswerSerializer

class NestedAnswer():
    def __init__(self, answerText=None, statusText=None):
        self.string = answerText
        self.status = statusText

class QuestionNestedView(APIView):

    def get(self, request):
        questions = Question.objects.all()
        serialized_questions = []
        for q in questions:
            question_string = q.questionText
            answer1_string= q.option_1
            answer2_string = q.option_2
            answer3_string = q.option_3
            answer4_string = q.option_4

            answer1_status = 'incorrect'
            answer2_status = 'incorrect'
            answer3_status = 'incorrect'
            answer4_status = 'incorrect'

            if (q.correctAnswerOption==1):
                answer1_status = 'correct'
            elif (q.correctAnswerOption==2):
                answer2_status = 'correct'
            elif (q.correctAnswerOption == 3):
                answer3_status = 'correct'
            elif(q.correctAnswerOption == 4):
                answer4_status = 'correct'
            
            Answer1 = NestedAnswer(answer1_string, answer1_status)
            Answer2 = NestedAnswer(answer2_string, answer2_status)
            Answer3 = NestedAnswer(answer3_string, answer3_status)
            Answer4 = NestedAnswer(answer4_string, answer4_status)

            ans1_ser = NestedAnswerSerializer(Answer1)
            ans2_ser = NestedAnswerSerializer(Answer2)
            ans3_ser = NestedAnswerSerializer(Answer3)
            ans4_ser = NestedAnswerSerializer(Answer4)

            q_serialized = QuestionWithNestedAnswersSerializer(data = {
                'string':question_string,
                'Answer1':ans1_ser.data,
                'Answer2':ans2_ser.data,
                'Answer3':ans3_ser.data,
                'Answer4':ans4_ser.data
            })
            serialized_questions.append(q_serialized.initial_data)

        return Response(serialized_questions, status=status.HTTP_200_OK)

        
#########-------------------------------###################
# Nested Answer Question code end #
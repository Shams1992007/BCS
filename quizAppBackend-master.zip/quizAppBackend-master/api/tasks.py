import random
from django.utils import timezone

from django.db.models import Q
from django.db.models import Max
from django.dispatch import receiver
from django.db.models import Sum, Count
from django.db.models import F
from django.db.models.expressions import Window
from django.db.models.functions import Rank, DenseRank, RowNumber
from django.contrib.auth.models import User

from celery import shared_task
from .models import Tournament , Round, processRoundSignal, scheduleNotificationForRoundSignal, createRoundQuestionsSignal, TournamentScores, Profile, RoundToQuestionMapping, Question, TournamentRanking

from datetime import timedelta

from fcm_django.models import FCMDevice

#To run celery worker thread
#celery -A HOME worker -l INFO
# Alternative : celery -A HOME worker -l info --without-gossip --without-mingle --without-heartbeat -Ofair --pool=solo

#To run celery beat seperately from worker thread
#celery -A HOME beat -l info

# To run celery beat along with worker (Not supported in windows)
# celery -A HOME worker -B -l info

#To delete all pending tasks
#celery -A HOME purge


def send_notification(user_ids,title, message, data= None):
   try:
      devices = FCMDevice.objects.filter(user__in=user_ids)
      result = devices.send_message(title=title,body=message,
                          data=data,sound=True)
      return result
   except:
      pass

@shared_task
def sendRoundReminder(roundid):
    round = None
    try:
        round = Round.objects.get(id = roundid)
    except:
        print('Round not found')

    if round is not None:
        if round.roundNumber == 1:
            eligibleUsersIds = User.objects.values_list('id', flat=True)
            send_notification(user_ids= eligibleUsersIds, title= 'Tournament Alert!', message='Round 1 will start within a minute!')
        else:
            eligibleProfileIds = Profile.objects.filter(spentPointsForCurrentTournament= True).values_list('id', flat = True)

            eligibleUsersIds = User.objects.filter(profile__in =eligibleProfileIds).values_list('id', flat = True)

            print('eligible user ids are ' + str(eligibleProfileIds))

            send_notification(user_ids= eligibleUsersIds, title= 'Tournament Alert!', message='Round ' + str(round.roundNumber) + ' will start within a minute!')
    else:
        pass





@shared_task
def add(x, y):
    return x + y


@shared_task
def mul(x, y):
    return x * y


@shared_task
def xsum(numbers):
    return sum(numbers)


@shared_task
def updateTournamentTallyMonthly():
    allProfiles = Profile.objects.all()
    updatedProfiles = []
    for profile in allProfiles:
        profile.tournamentTally = 4
        updatedProfiles.append(profile)
    Profile.objects.bulk_update(updatedProfiles, ['tournamentTally'])



def randomQuestionSelection( allQuestions, noSelected):
    randomly_selected_questions = []
    number_of_available_questions = allQuestions.count()
    if number_of_available_questions>noSelected:
        random_indexes = random.sample(range(number_of_available_questions), noSelected)
        randomly_selected_questions = [allQuestions[i] for i in random_indexes]
    else:
        randomly_selected_questions = [q for q in allQuestions]
    return randomly_selected_questions


@shared_task
def createRoundQuestions(roundid):
    # Get the round
    round = Round.objects.get(id = roundid)

    minDifficulty = 0
    maxDifficulty = 8

    if(round.roundType == 'RE'):
        minDifficulty = 4
        maxDifficulty = 5
    elif(round.roundType == 'KN'):
        minDifficulty = 6
        maxDifficulty = 7
    

    numberOfMathQuestions = round.numberOfQuestions//2
    numberOfBanglaQuestions = round.numberOfQuestions//4
    numberOfEnglishQuestions = round.numberOfQuestions -(numberOfMathQuestions + numberOfBanglaQuestions)

    allMathQuestions = Question.objects.filter(Q(subject='Math') & Q(difficulty__range= (minDifficulty,maxDifficulty)) & Q(recentlyInTournament = False))

    allBanglaQuesions = Question.objects.filter(Q(subject='Bangla') & Q(difficulty__range= (minDifficulty,maxDifficulty)) & Q(recentlyInTournament = False))

    allEnglishQuestions = Question.objects.filter(Q(subject='English') & Q(difficulty__range= (minDifficulty,maxDifficulty)) & Q(recentlyInTournament = False))

    mathQuestions= randomQuestionSelection(allMathQuestions, numberOfMathQuestions)
    banglaQuesions = randomQuestionSelection(allBanglaQuesions, numberOfBanglaQuestions)
    englishQuestions = randomQuestionSelection(allEnglishQuestions, numberOfEnglishQuestions)


    # Randomly select some questions for this round
    #selectedQuestions = mathQuestions.union(banglaQuesions,englishQuestions)
    selectedQuestions = mathQuestions + banglaQuesions + englishQuestions

    updatedQuestions = []
    newRoundQuestionMappings = []
    
    # populate the RoundToQuestionMapping table with this questions
    for i,q  in enumerate(selectedQuestions):
        #Update question used field
        q.recentlyInTournament = True
        updatedQuestions.append(q)
        # q.save()

        #create round question mappings
        questionEntry = RoundToQuestionMapping(round=round, question=q, questionSerialNumber = i+1)
        newRoundQuestionMappings.append(questionEntry)
        # questionEntry.save()

    #Do database transactions in bulk
    Question.objects.bulk_update(updatedQuestions, ['recentlyInTournament'])

    RoundToQuestionMapping.objects.bulk_create(newRoundQuestionMappings)



def deleteSubsequentRounds(tournament, round):
    subsequentRounds = Round.objects.filter(tournament=tournament, roundNumber__gte= (round.roundNumber + 1))

    for subsequentRound in subsequentRounds:
        mappings = RoundToQuestionMapping.objects.filter(round = subsequentRound)

        upadatedQuestions = []
        for roundToQuestionMap in mappings:
            q = roundToQuestionMap.question
            q.recentlyInTournament = False
            upadatedQuestions.append(q)

        Question.objects.bulk_update(upadatedQuestions, ['recentlyInTournament'])
        #delete unused questions from mapping table
        subsequentRound.delete()



@shared_task
def processRound(roundid):
    print(roundid)
    cutoffPercentage = 0.75
    # Get the round and associated tournament id
    round = Round.objects.get(id = roundid)
    tournament = round.tournament

    FinalRound = False
    if tournament.numberOfRounds == round.roundNumber:
        FinalRound = True

    print('current round name ' + round.name)
    # Get all scores submitted for this round
    allscores = TournamentScores.objects.filter(round=round, tournament=tournament)

    #if allscores is not empty calculate maximum and cutoff scores
    maxScore = 0
    cutScore = 0
    if len(allscores)>0:
        maxScore = list(TournamentScores.objects.filter(round=round, tournament=tournament).aggregate(Max('score')).values())[0]
        # maxScore = maxScoreQuery['score__max']
        cutScore = float(maxScore)*cutoffPercentage

    print("Highest score is "+ str(maxScore))
    print("Cut off score is " + str(cutScore))

    #Mark unused questions of knockout round as unused
    if round.roundType == 'KN':
        firstUnusedSerial = int(maxScore) + 1
        lastUnusedSerial = round.numberOfQuestions
        mappings = RoundToQuestionMapping.objects.filter(round = round,questionSerialNumber__range=(firstUnusedSerial, lastUnusedSerial))

        upadatedQuestions = []
        for roundToQuestionMap in mappings:
            q = roundToQuestionMap.question
            q.recentlyInTournament = False
            upadatedQuestions.append(q)

        Question.objects.bulk_update(upadatedQuestions, ['recentlyInTournament'])
        #delete unused questions from mapping table
        mappings.delete()
        #update number of questions in round
        round.numberOfQuestions = maxScore
        round.save()

    

    #Update ranking table
    allTournamentScores = TournamentScores.objects.filter( tournament=tournament).values('tournament','user').annotate(totalscore=Sum('score'), playedRounds = Count('score')).order_by('-playedRounds','-totalscore').annotate(
        rank=Window(
            expression=Rank(),
            order_by=F('totalscore').desc(),
            partition_by = [F('playedRounds')],
        ),
    )

    for rankingScore in allTournamentScores:
        print(rankingScore)

        rankEntry = TournamentRanking.objects.filter(user = rankingScore['user'], tournament=rankingScore['tournament'])


        if len(rankEntry)<1:
            currentUser = User.objects.get(id = rankingScore['user'])
            currentTournament = Tournament.objects.get(id = rankingScore['tournament'])

            newRankEntry = TournamentRanking(user=currentUser, tournament= currentTournament, ranking=rankingScore['rank'], playedRounds=rankingScore['playedRounds'], totalScore=rankingScore['totalscore'])
            newRankEntry.save()
        else:
            editRankEntry = rankEntry[0]
            editRankEntry.ranking = rankingScore['rank']
            editRankEntry.playedRounds = rankingScore['playedRounds']
            editRankEntry.totalScore = rankingScore['totalscore']
            editRankEntry.save()

    #Fix partitioned ranking
    lastRoundNumber = round.roundNumber
    #secondLastRoundNumber = lastRoundNumber - 1
    for secondLastRoundNumber in range(lastRoundNumber-1, 0, -1):
        lastRank = TournamentRanking.objects.filter(tournament=tournament, playedRounds=secondLastRoundNumber + 1).aggregate(Max('ranking'))['ranking__max']
        print(lastRank)
        if lastRank is None:
            lastRank = 0

        allRanksSecondLast = TournamentRanking.objects.filter(tournament=tournament, playedRounds=secondLastRoundNumber)

        for currentRank in allRanksSecondLast:
            currentRank.ranking += lastRank
            currentRank.save()

    #Debug code
    allranks = TournamentRanking.objects.filter(tournament=tournament)
    for r in allranks:
        print(r.user)
        print(r.ranking)



    profilesEligibleForNextRound = []
    
    usersEligibleForNextRound = []
    usersNotEligibleForNextRound = []
    # The profiles that scored lower than cutScore will lose eligibility for 
    # next round
    for tournamentScore in allscores:
        if tournamentScore.score < cutScore:
            profile = tournamentScore.user.profile

            print('not eligible for next round' + profile.user.username)

            usersNotEligibleForNextRound.append(profile.user.id)

            profile.spentPointsForCurrentTournament = False
            profile.tournamentTally -= 1
            profile.save()
        else:
            profile = tournamentScore.user.profile
            profilesEligibleForNextRound.append(profile)
            usersEligibleForNextRound.append(profile.user.id)

    send_notification(user_ids= usersEligibleForNextRound, title='Round ' + str(round.roundNumber) + ' Result!', message= 'Congrats, You passed the round! You are eligible for next round!')

    send_notification(user_ids= usersNotEligibleForNextRound, title='Round ' + str(round.roundNumber) + ' Result!', message= 'Sorry, You did not pass this round, so you can not participate in any subsequent round!')

    if len(profilesEligibleForNextRound)< 1:
        # Previous round winner is tournament winner
        winners = TournamentRanking.objects.filter(tournament= tournament, ranking= 1)

        print('winners are: ')
        for winner in winners:
            print(winner.user.username)
            tournament.tournamentWinners.add(winner.user)
        print()

        tournament.TournamentFinished = True
        tournament.endTime = timezone.now()
        tournament.save()
        #cancel all subsequent rounds in this tournament
        deleteSubsequentRounds(tournament, round)

    elif len(profilesEligibleForNextRound) == 1:
        winner = profilesEligibleForNextRound[0].user
        print('winner is')
        print(winner.username)
        tournament.tournamentWinners.add(winner)
        tournament.TournamentFinished = True
        tournament.endTime = timezone.now()
        tournament.save()
        #cancel all subsequent rounds in this tournament
        deleteSubsequentRounds(tournament, round)
     
    else:
        if FinalRound:
            # Previous round winner is tournament winner
            winners = TournamentRanking.objects.filter(tournament= tournament, ranking= 1)
            print('winners are: ')
            for winner in winners:
                print(winner.user.username)
                tournament.tournamentWinners.add(winner.user)
            print()

            tournament.TournamentFinished = True
            tournament.endTime = timezone.now()
            tournament.save()
            
        else:
            #Continue tournament without interrupting
            pass
    
    #Delete winners with lower lifetime points if multiple winners
    if tournament.TournamentFinished:
        allWinnersBasedOnRank=  tournament.tournamentWinners.all()
        if len(allWinnersBasedOnRank)> 1:
            newRankBasedOnTotalPoints = Profile.objects.filter(user__in = allWinnersBasedOnRank).annotate( RankOnPoints = Window(expression=Rank(),
            order_by=F('total_points').desc()
            )
            )

            
            # Remove winners whose new rank is not one
            for newRank in newRankBasedOnTotalPoints:
                if newRank.RankOnPoints > 1:
                    print('removing')
                    print(newRank.user.username)
                    tournament.tournamentWinners.remove(newRank.user)


        allWinners = tournament.tournamentWinners.all()
        allWinnersIds = allWinners.values_list('id', flat=True)
        send_notification(user_ids=allWinnersIds, title='Congratulations!!', message= 'You won the '+ tournament.name + ' tournament!')

    

    # The profiles that did not submit a score for this round, did not
    # participate in this round(whether they spent points or not).
    # So they must lose eligibility for all
    # other rounds in this tournament
    
    if round.roundNumber == 1: 
        participants = []
        for tournamentScore in allscores:
            profile= tournamentScore.user.profile
            participants.append(profile.id)

        nonParticipants = Profile.objects.exclude(id__in = participants)

        for profile in nonParticipants:
            print('not eligible for next round' + profile.user.username)
            profile.spentPointsForCurrentTournament = False
            profile.tournamentTally -= 1
            profile.save()

    elif round.roundNumber > 1:
        previousRoundNumber = round.roundNumber -1
        print('previous round number '+ str(previousRoundNumber))
        #Find the previous round first
        previousRoundQuery = Round.objects.filter(tournament=tournament, roundNumber= previousRoundNumber)
        if len(previousRoundQuery)> 0:
            previousRound = previousRoundQuery[0]
            print(previousRound.name)
            # Now find all the participants of previous round
            # 
            allScoresPreviousRound = TournamentScores.objects.filter(round=previousRound, tournament=tournament)

            #if allscores is not empty calculate maximum and cutoff scores
            prevMaxScore = 0
            prevCutScore = 0
            if len(allScoresPreviousRound)>0:
                prevMaxScore = list(TournamentScores.objects.filter(round=previousRound, tournament=tournament).aggregate(Max('score')).values())[0]
                # maxScore = maxScoreQuery['score__max']
                prevCutScore = float(prevMaxScore)*cutoffPercentage

            print("Previous Highest score is "+ str(prevMaxScore))
            print("Previous Cut off score is " + str(prevCutScore))
            
            previousRoundWinners = []
            for previousScore in allScoresPreviousRound:
                if previousScore.score >= prevCutScore:
                    winner = previousScore.user.profile
                    previousRoundWinners.append(winner.id)
            print('previous round winners')
            print(previousRoundWinners)

            participants = []
            for tournamentScore in allscores:
                profile= tournamentScore.user.profile
                participants.append(profile.id)
            print('current round participants')
            print(participants)

            nonParticipentIdList = list(set(previousRoundWinners) - set(participants))
            print('current round nonparticipants')
            print(nonParticipentIdList)

            nonParticipents = Profile.objects.filter(id__in= nonParticipentIdList)

            for profile in nonParticipents:
                print('not eligible for next round' + profile.user.username)
                profile.spentPointsForCurrentTournament = False
                profile.tournamentTally -= 1
                profile.save()

    round.processedStatus = True
    round.save()








@receiver(processRoundSignal)
def processRoundSignalReceiver(sender, **kwargs):
    roundid = kwargs['id']
    round = Round.objects.get(id = roundid)

    #call task to create questions
    createRoundQuestions.delay(roundid)

    startTime = round.startTime
    processAfter = round.perQuestionTime*round.numberOfQuestions + timedelta(minutes = 5)
    
    # process round after a constant time
    #processRound.apply_async((roundid,), eta =(startTime + timedelta(minutes = 5)))

    #call task to process scores of users
    processRound.apply_async((roundid,), eta =(startTime + processAfter))

# @receiver(createRoundQuestionsSignal)
# def createRoundQuestionsSignalReciever(sender, **kwargs):
#     # round = Round.objects.get(id = kwargs['id'])
#     createRoundQuestions.delay(kwargs['id'])

@receiver(scheduleNotificationForRoundSignal)
def scheduleNotificationForRoundSignalReceiver(sender, **kwargs):
    roundid = kwargs['id']
    round = Round.objects.get(id = roundid)

    startTime = round.startTime
    sendBefore = timedelta(minutes = 1)
    
    #call task to sendNotification
    sendRoundReminder.apply_async((roundid,), eta =(startTime - sendBefore))


